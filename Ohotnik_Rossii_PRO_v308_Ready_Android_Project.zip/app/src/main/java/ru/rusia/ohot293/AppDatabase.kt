package ru.rusia.ohot293

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

@Database(
    entities = [
        CartridgeEntity::class,
        GunEntity::class,
        MedItemEntity::class,
        SurvivalMemoEntity::class,
        FaunaEntity::class
    ],
    version = 308,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): OhotnikDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ohotnik_rossii_v308.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

object JsonAssetSeeder {
    suspend fun ensureSeeded(context: Context, db: AppDatabase) = withContext(Dispatchers.IO) {
        val dao = db.dao()
        if (dao.getCartridgeCount() > 0) return@withContext

        val candidateFiles = listOf(
            "ALL_IN_ONE_ohotnik_room_db.json",
            "ohotnik_room_db.json",
            "ohotnik_room_database.json"
        )
        var rawJson = ""
        for (fileName in candidateFiles) {
            try {
                rawJson = context.assets.open(fileName).bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (rawJson.isNotBlank()) break
            } catch (_: Exception) {}
        }
        if (rawJson.isBlank()) return@withContext
        val root = JSONObject(rawJson)

        // 1. Импорт каталога патронов и оружия
        val catAmmo = root.getJSONObject("catalog_calibers_and_ammo")
        val cartArr = catAmmo.getJSONArray("cartridges")
        val cartridgeEntities = mutableListOf<CartridgeEntity>()
        for (i in 0 until cartArr.length()) {
            val c = cartArr.getJSONObject(i)
            val rel = c.optJSONObject("reload_recipe")
            cartridgeEntities.add(
                CartridgeEntity(
                    id = c.optString("id"),
                    title = c.optString("title"),
                    lengthMm = c.optString("length_mm"),
                    diameterMm = c.optString("diameter_mm"),
                    bulletWeightAndPowder = c.optString("bullet_weight_and_powder"),
                    velocityV0 = c.optString("velocity_v0"),
                    energyE0 = c.optString("energy_e0"),
                    storePrice = c.optString("store_price"),
                    selfReloadPrice = c.optString("self_reload_price"),
                    descriptionAndGame = c.optString("description_and_game"),
                    imageAsset = c.optString("image_asset"),
                    reloadPowderName = rel?.optString("powder_name") ?: "",
                    reloadSummerLoad = rel?.optString("summer_load") ?: "",
                    reloadWinterLoad = rel?.optString("winter_load") ?: "",
                    reloadSlugLoad = rel?.optString("slug_load") ?: "",
                    reloadWadNote = rel?.optString("wad_and_crimp_note") ?: "",
                    reloadPrimer = rel?.optString("primer") ?: "",
                    storeCostRub = rel?.optInt("store_cost_rub", 65) ?: 65,
                    selfNewHullCostRub = rel?.optInt("self_new_hull_cost_rub", 38) ?: 38,
                    selfReusedHullCostRub = rel?.optInt("self_reused_hull_cost_rub", 26) ?: 26,
                    powderGramsPerRound = rel?.optDouble("powder_grams_per_round", 2.1) ?: 2.1,
                    projectileGramsPerRound = rel?.optDouble("projectile_grams_per_round", 32.0) ?: 32.0,
                    costBreakdown = rel?.optString("cost_breakdown") ?: ""
                )
            )
        }
        dao.insertCartridges(cartridgeEntities)

        val gunsArr = catAmmo.getJSONArray("guns_catalog")
        val gunEntities = mutableListOf<GunEntity>()
        for (i in 0 until gunsArr.length()) {
            val g = gunsArr.getJSONObject(i)
            gunEntities.add(
                GunEntity(
                    id = g.optString("id"),
                    name = g.optString("name"),
                    category = g.optString("category"),
                    type = g.optString("type"),
                    caliber = g.optString("caliber"),
                    priceRange = g.optString("price_range"),
                    imageAsset = g.optString("image_asset"),
                    ammoId = g.optString("ammo_id"),
                    overallLength = g.optString("overall_length"),
                    barrelLength = g.optString("barrel_length"),
                    magazineCapacity = g.optString("magazine_capacity"),
                    shortDescription = g.optString("short_description"),
                    overview = g.optString("overview"),
                    pros = g.optString("pros"),
                    cons = g.optString("cons"),
                    inspectionTips = g.optString("inspection_tips"),
                    recommendedAmmo = g.optString("recommended_ammo"),
                    maintenance = g.optString("maintenance")
                )
            )
        }
        dao.insertGuns(gunEntities)

        // 2. Импорт полевой медицины
        val medObj = root.getJSONObject("field_medicine_and_first_aid")
        val medEntities = mutableListOf<MedItemEntity>()

        // 2.1 Анатомические зоны
        val zonesArr = medObj.getJSONArray("body_zones")
        for (i in 0 until zonesArr.length()) {
            val z = zonesArr.getJSONObject(i)
            medEntities.add(
                MedItemEntity(
                    id = "zone_" + z.optString("id"),
                    section = "body_zones",
                    category = z.optString("id"),
                    title = z.optString("name"),
                    subtitleOrDanger = z.optString("danger_level"),
                    badge = z.optString("icon") + " ЗОНА ТЕЛА",
                    symptomsOrSummary = z.optString("symptoms"),
                    stepsWithKitJson = (z.optJSONArray("steps_with_kit") ?: JSONArray()).toString(),
                    stepsKnifeOnlyJson = (z.optJSONArray("steps_only_knife") ?: JSONArray()).toString(),
                    forbiddenOrWarning = z.optString("strictly_forbidden"),
                    taigaSecret = z.optJSONObject("infographic_scheme")?.optString("taiga_tip") ?: "",
                    photoAsset = z.optString("photo_asset"),
                    schemeIllustrationAsset = z.optString("scheme_illustration_asset")
                )
            )
        }

        // 2.2 Атлас травм
        val traumaArr = medObj.getJSONArray("trauma_atlas")
        for (i in 0 until traumaArr.length()) {
            val t = traumaArr.getJSONObject(i)
            medEntities.add(
                MedItemEntity(
                    id = t.optString("id"),
                    section = "trauma_atlas",
                    category = t.optString("category"),
                    title = t.optString("title"),
                    subtitleOrDanger = t.optString("badge"),
                    badge = t.optString("badge"),
                    symptomsOrSummary = t.optString("summary"),
                    stepsWithKitJson = (t.optJSONArray("step_by_step_instructions") ?: JSONArray()).toString(),
                    stepsKnifeOnlyJson = "[]",
                    forbiddenOrWarning = "",
                    taigaSecret = t.optJSONObject("infographic_scheme")?.optString("taiga_tip") ?: "",
                    photoAsset = t.optString("photo_asset"),
                    schemeIllustrationAsset = t.optString("scheme_illustration_asset")
                )
            )
        }

        // 2.3 Помощь одним ножом
        val knifeArr = medObj.getJSONArray("knife_only_aid")
        for (i in 0 until knifeArr.length()) {
            val k = knifeArr.getJSONObject(i)
            medEntities.add(
                MedItemEntity(
                    id = k.optString("id"),
                    section = "knife_only",
                    category = "knife",
                    title = k.optString("title"),
                    subtitleOrDanger = k.optString("badge"),
                    badge = k.optString("badge"),
                    symptomsOrSummary = "",
                    stepsWithKitJson = (k.optJSONArray("steps") ?: JSONArray()).toString(),
                    stepsKnifeOnlyJson = "[]",
                    forbiddenOrWarning = "",
                    taigaSecret = k.optJSONObject("infographic_scheme")?.optString("taiga_tip") ?: "",
                    photoAsset = k.optString("photo_asset"),
                    schemeIllustrationAsset = k.optString("scheme_illustration_asset")
                )
            )
        }

        // 2.4 Таёжные лайфхаки
        val taigaArr = medObj.getJSONArray("taiga_forest_lifehacks")
        for (i in 0 until taigaArr.length()) {
            val h = taigaArr.getJSONObject(i)
            val stepsArr = h.optJSONArray("steps") ?: JSONArray()
            val formattedSteps = JSONArray()
            for (j in 0 until stepsArr.length()) {
                val st = stepsArr.getJSONObject(j)
                formattedSteps.put("${st.optString("num")} [${st.optString("badge")}] ${st.optString("title")}: ${st.optString("description")}")
            }
            medEntities.add(
                MedItemEntity(
                    id = h.optString("id"),
                    section = "taiga_hacks",
                    category = h.optString("group"),
                    title = h.optString("title"),
                    subtitleOrDanger = h.optString("subtitle"),
                    badge = "ТАЁЖНАЯ МЕДИЦИНА",
                    symptomsOrSummary = h.optString("group"),
                    stepsWithKitJson = formattedSteps.toString(),
                    stepsKnifeOnlyJson = "[]",
                    forbiddenOrWarning = "",
                    taigaSecret = h.optString("taiga_secret"),
                    photoAsset = h.optString("photo_asset"),
                    schemeIllustrationAsset = h.optString("scheme_illustration_asset")
                )
            )
        }

        // 2.5 Целебные и ядовитые растения тайги
        val plantsArr = medObj.getJSONArray("medicinal_and_poisonous_plants")
        for (i in 0 until plantsArr.length()) {
            val p = plantsArr.getJSONObject(i)
            val steps = JSONArray().apply {
                put("Где найти и как узнать: " + p.optString("where_and_how_to_spot"))
                put("Действующие вещества: " + p.optString("active_properties"))
                put("Полевой рецепт применения: " + p.optString("field_recipe"))
            }
            medEntities.add(
                MedItemEntity(
                    id = p.optString("id"),
                    section = "plants",
                    category = p.optString("category"),
                    title = p.optString("title"),
                    subtitleOrDanger = p.optString("badge"),
                    badge = p.optString("badge"),
                    symptomsOrSummary = p.optString("where_and_how_to_spot"),
                    stepsWithKitJson = steps.toString(),
                    stepsKnifeOnlyJson = "[]",
                    forbiddenOrWarning = if (p.optBoolean("is_poisonous")) "СМЕРТЕЛЬНО ЯДОВИТОЕ РАСТЕНИЕ! Категорически запрещено брать в рот или тереть глаза руками после контакта." else "",
                    taigaSecret = p.optString("field_recipe"),
                    photoAsset = p.optString("photo_asset"),
                    schemeIllustrationAsset = "",
                    isPoisonous = p.optBoolean("is_poisonous", false)
                )
            )
        }

        // 2.6 Аптечка охотника (1 и 2 эшелон)
        val kitArr = medObj.getJSONArray("first_aid_kit_checklist")
        for (i in 0 until kitArr.length()) {
            val k = kitArr.getJSONObject(i)
            val ech = k.optInt("echelon", 1)
            medEntities.add(
                MedItemEntity(
                    id = k.optString("id"),
                    section = "kit",
                    category = "ech_$ech",
                    title = k.optString("name"),
                    subtitleOrDanger = "Эшелон $ech",
                    badge = if (ech == 1) "1 ЭШЕЛОН (НА СЕБЕ)" else "2 ЭШЕЛОН (В РЮКЗАКЕ)",
                    symptomsOrSummary = k.optString("description"),
                    stepsWithKitJson = "[]",
                    stepsKnifeOnlyJson = "[]",
                    forbiddenOrWarning = "",
                    taigaSecret = "",
                    photoAsset = k.optString("photo_asset"),
                    schemeIllustrationAsset = k.optString("scheme_illustration_asset")
                )
            )
        }

        // 2.7 Схемы тампонады раны в разрезе
        val tampArr = medObj.getJSONArray("wound_packing_cross_sections")
        for (i in 0 until tampArr.length()) {
            val tm = tampArr.getJSONObject(i)
            medEntities.add(
                MedItemEntity(
                    id = tm.optString("id"),
                    section = "tamponade",
                    category = "tamponade",
                    title = tm.optString("title"),
                    subtitleOrDanger = "Атлас тампонады в разрезе",
                    badge = "СХЕМА В РАЗРЕЗЕ",
                    symptomsOrSummary = tm.optString("description"),
                    stepsWithKitJson = "[]",
                    stepsKnifeOnlyJson = "[]",
                    forbiddenOrWarning = "",
                    taigaSecret = "",
                    photoAsset = tm.optString("image_asset"),
                    schemeIllustrationAsset = ""
                )
            )
        }
        dao.insertMedItems(medEntities)

        // 3. Импорт выживания, шагов лицензии и фауны
        val survObj = root.getJSONObject("hunter_memos_and_survival")
        val memoEntities = mutableListOf<SurvivalMemoEntity>()

        val survArr = survObj.getJSONArray("survival_algorithms")
        for (i in 0 until survArr.length()) {
            val s = survArr.getJSONObject(i)
            memoEntities.add(
                SurvivalMemoEntity(
                    id = s.optString("id"),
                    section = "survival",
                    title = s.optString("title"),
                    subtitle = "Алгоритм выживания в тайге",
                    instructions = s.optString("instructions"),
                    badgeOrCost = "ПАМЯТКА ВЫЖИВАНИЯ"
                )
            )
        }

        val stepsArr = survObj.getJSONArray("licensing_steps")
        for (i in 0 until stepsArr.length()) {
            val st = stepsArr.getJSONObject(i)
            memoEntities.add(
                SurvivalMemoEntity(
                    id = "step_" + st.optInt("id", i + 1),
                    section = "licensing_steps",
                    title = st.optString("title"),
                    subtitle = st.optString("organization") + " • " + st.optString("address"),
                    instructions = st.optString("details"),
                    badgeOrCost = st.optString("cost")
                )
            )
        }
        dao.insertSurvivalMemos(memoEntities)

        val faunaArr = survObj.getJSONArray("fauna_encyclopedia")
        val faunaEntities = mutableListOf<FaunaEntity>()
        for (i in 0 until faunaArr.length()) {
            val f = faunaArr.getJSONObject(i)
            val det = f.optJSONObject("details")
            val vet = f.optJSONObject("veterinary_control")
            faunaEntities.add(
                FaunaEntity(
                    id = f.optString("id"),
                    name = f.optString("name"),
                    category = f.optString("category"),
                    season = f.optString("season"),
                    limitsAndNorms = f.optString("limits_and_norms"),
                    tacticsAndWeapons = f.optString("tactics_and_weapons"),
                    imageAsset = f.optString("image_asset"),
                    regionsText = f.optString("regions_text"),
                    habitat = det?.optString("habitat") ?: "",
                    tracesAndSigns = det?.optString("traces_and_signs") ?: "",
                    recommendedAmmo = det?.optString("recommended_ammo") ?: "",
                    huntingMethods = det?.optString("hunting_methods") ?: "",
                    fieldDressingAndCooking = det?.optString("field_dressing_and_cooking") ?: "",
                    vetStatus = vet?.optString("status") ?: "",
                    vetInspect = vet?.optString("what_to_inspect") ?: "",
                    vetDiseases = vet?.optString("diseases") ?: "",
                    vetConsequences = vet?.optString("consequences_and_cooking") ?: ""
                )
            )
        }
        dao.insertFauna(faunaEntities)
    }
}

