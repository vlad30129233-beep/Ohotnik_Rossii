package ru.rusia.ohot293

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import kotlin.math.roundToInt

object TaigaPalette {
    val BgMain = Color(0xFF0A1410)
    val BgSecondary = Color(0xFF10221B)
    val BgCard = Color(0xFF10221B)
    val BgElevated = Color(0xFF173026)
    val GoldAccent = Color(0xFFD4A338)
    val GoldBright = Color(0xFFFDE047)
    val EmeraldAccent = Color(0xFF34D399)
    val DangerRed = Color(0xFFEF4444)
    val DangerBg = Color(0xFF3B1219)
    val TextPrimary = Color(0xFFF4F7F5)
    val TextMuted = Color(0xFF8EA396)
    val BorderGold = Color(0x55FDE047)
}

private val TaigaColorScheme = darkColorScheme(
    primary = TaigaPalette.GoldAccent,
    onPrimary = TaigaPalette.BgMain,
    secondary = TaigaPalette.EmeraldAccent,
    onSecondary = TaigaPalette.BgMain,
    background = TaigaPalette.BgMain,
    onBackground = TaigaPalette.TextPrimary,
    surface = TaigaPalette.BgCard,
    onSurface = TaigaPalette.TextPrimary,
    error = TaigaPalette.DangerRed,
    onError = Color.White
)

@Composable
fun OhotnikTaigaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TaigaColorScheme,
        content = content
    )
}
 + МОДАЛЬНОЕ ОКНО ЗУМА
// ============================================================================

@Composable
fun AssetPhotoImage(
    assetPath: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    onClickZoom: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = assetPath) {
        if (assetPath.isBlank()) {
            value = null
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            try {
                val cleanPath = assetPath.removePrefix("./").removePrefix("/")
                context.assets.open(cleanPath).use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) {
                null
            }
        }
    }

    val clickMod = if (onClickZoom != null) modifier.clickable { onClickZoom() } else modifier

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = contentDescription,
            contentScale = contentScale,
            modifier = clickMod
        )
    } else {
        Box(
            modifier = clickMod
                .background(TaigaPalette.BgSecondary)
                .border(1.dp, TaigaPalette.BorderGold, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "📷 $assetPath",
                color = TaigaPalette.TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}

@Composable
fun FullscreenZoomPhotoDialog(
    assetPath: String,
    title: String,
    onDismiss: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var rotationDeg by remember { mutableFloatStateOf(0f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xF5060C09)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        color = TaigaPalette.GoldBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = TaigaPalette.DangerRed)
                    ) {
                        Text("✕ Закрыть", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.5.dp, TaigaPalette.GoldAccent, RoundedCornerShape(12.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 4f)
                                if (scale > 1f) {
                                    offsetX += pan.x
                                    offsetY += pan.y
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AssetPhotoImage(
                        assetPath = assetPath,
                        contentDescription = title,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY,
                                rotationZ = rotationDeg
                            )
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                ) {
                    OutlinedButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f; rotationDeg = 0f }) {
                        Text("1:1 Сброс", color = TaigaPalette.GoldBright)
                    }
                    OutlinedButton(onClick = { scale = if (scale < 2f) 2f else 1f }) {
                        Text("🔍 Зум 200%", color = TaigaPalette.GoldBright)
                    }
                    OutlinedButton(onClick = { rotationDeg = (rotationDeg + 90f) % 360f }) {
                        Text("🔄 Поворот 90°", color = TaigaPalette.GoldBright)
                    }
                }
            }
        }
    }
}

// ============================================================================
// 8. ГЛАВНЫЕ ЭКРАНЫ НАТИВНОГО ПРИЛОЖЕНИЯ (JETPACK COMPOSE)
// ============================================================================

enum class MainNavTab(val title: String, val iconEmoji: String) {
    AMMO_AND_GUNS("Патроны и Оружие", "💥"),
    FIELD_MEDICINE("Полевая медицина", "🚑"),
    SURVIVAL_MEMOS("Выживание и Справки", "🧭"),
    FAUNA_ATLAS("Звери и Птицы", "🦌")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OhotnikMainScreen(vm: OhotnikViewModel) {
    val isSeeding by vm.isSeeding.collectAsState()
    val searchQuery by vm.searchQuery.collectAsState()
    val tqRemainingSec by vm.tourniquetRemainingSec.collectAsState()
    val tqZoneLabel by vm.tourniquetZoneLabel.collectAsState()

    var currentTab by remember { mutableStateOf(MainNavTab.AMMO_AND_GUNS) }
    var zoomModalAsset by remember { mutableStateOf<Pair<String, String>?>(null) }
    var torchActive by remember { mutableStateOf(false) }

    if (zoomModalAsset != null) {
        FullscreenZoomPhotoDialog(
            assetPath = zoomModalAsset!!.first,
            title = zoomModalAsset!!.second,
            onDismiss = { zoomModalAsset = null }
        )
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(TaigaPalette.BgElevated, TaigaPalette.BgMain)
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ОХОТНИК РОССИИ ПРО v308",
                            color = TaigaPalette.GoldBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Полностью нативная сборка (Kotlin • Room • Офлайн)",
                            color = TaigaPalette.TextMuted,
                            fontSize = 11.sp
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalIconButton(
                            onClick = { torchActive = vm.hardware.toggleTorch() },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = if (torchActive) TaigaPalette.GoldAccent else TaigaPalette.BgCard
                            )
                        ) {
                            Text("🔦", fontSize = 16.sp)
                        }
                        FilledTonalIconButton(
                            onClick = { vm.triggerWhistle() },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = TaigaPalette.DangerBg
                            )
                        ) {
                            Text("🚨", fontSize = 16.sp)
                        }
                    }
                }

                // Полоса активного таймера кровоостанавливающего жгута
                AnimatedVisibility(visible = tqRemainingSec > 0) {
                    val mins = tqRemainingSec / 60
                    val secs = tqRemainingSec % 60
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TaigaPalette.DangerRed)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⏱ ЖГУТ ($tqZoneLabel): %02d:%02d".format(mins, secs),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                        TextButton(onClick = { vm.stopTourniquetTimer() }) {
                            Text("СНЯТЬ", color = TaigaPalette.GoldBright, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { vm.searchQuery.value = it },
                    placeholder = {
                        Text(
                            "Поиск по калибрам, ранениям, травам, зверям...",
                            color = TaigaPalette.TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    singleLine = true,
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { vm.searchQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Очистить", tint = TaigaPalette.GoldAccent)
                            }
                        } else {
                            Icon(Icons.Default.Search, contentDescription = "Поиск", tint = TaigaPalette.GoldAccent)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = TaigaPalette.BgSecondary,
                tonalElevation = 8.dp
            ) {
                MainNavTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Text(tab.iconEmoji, fontSize = 18.sp) },
                        label = {
                            Text(
                                tab.title,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TaigaPalette.GoldBright,
                            selectedTextColor = TaigaPalette.GoldBright,
                            indicatorColor = TaigaPalette.BgElevated,
                            unselectedTextColor = TaigaPalette.TextMuted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(TaigaPalette.BgMain)
                .padding(innerPadding)
        ) {
            if (isSeeding) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = TaigaPalette.GoldAccent)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "Инициализация локальной базы Room...",
                        color = TaigaPalette.GoldBright,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                when (currentTab) {
                    MainNavTab.AMMO_AND_GUNS -> AmmoAndGunsScreen(
                        vm = vm,
                        searchQuery = searchQuery,
                        onOpenZoom = { path, title -> zoomModalAsset = path to title }
                    )
                    MainNavTab.FIELD_MEDICINE -> FieldMedicineScreen(
                        vm = vm,
                        searchQuery = searchQuery,
                        onOpenZoom = { path, title -> zoomModalAsset = path to title }
                    )
                    MainNavTab.SURVIVAL_MEMOS -> SurvivalAndMemosScreen(
                        vm = vm,
                        searchQuery = searchQuery
                    )
                    MainNavTab.FAUNA_ATLAS -> FaunaCatalogScreen(
                        vm = vm,
                        searchQuery = searchQuery,
                        onOpenZoom = { path, title -> zoomModalAsset = path to title }
                    )
                }
            }
        }
    }
}

// ============================================================================
// 8.1 ЭКРАН «КАТАЛОГ КАЛИБРОВ, БОЕПРИПАСОВ, САМОКРУТА И ОРУЖИЯ»
// ============================================================================

@Composable
fun AmmoAndGunsScreen(
    vm: OhotnikViewModel,
    searchQuery: String,
    onOpenZoom: (String, String) -> Unit
) {
    val cartridges by vm.cartridges.collectAsState()
    val guns by vm.guns.collectAsState()
    var subTab by remember { mutableIntStateOf(0) } // 0 = Патроны (19), 1 = Калькулятор самокрута, 2 = Оружие (60)
    var batchCountText by remember { mutableStateOf("25") }
    var selectedCartridgeId by remember { mutableStateOf("ammo_12_70") }

    val q = searchQuery.trim().lowercase()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                0 to "💥 Калибры (${cartridges.size})",
                1 to "⚖️ Самокрут",
                2 to "🔫 Оружие (${guns.size})"
            ).forEach { (idx, label) ->
                FilterChip(
                    selected = subTab == idx,
                    onClick = { subTab = idx },
                    label = { Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }
        }

        when (subTab) {
            0 -> {
                val filtered = cartridges.filter {
                    q.isEmpty() || (it.title + " " + it.bulletWeightAndPowder + " " + it.descriptionAndGame)
                        .lowercase().contains(q)
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { c ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, TaigaPalette.BorderGold, RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                AssetPhotoImage(
                                    assetPath = c.imageAsset,
                                    contentDescription = c.title,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(TaigaPalette.BgMain),
                                    onClickZoom = { onOpenZoom(c.imageAsset, c.title) }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "💥 ${c.title}",
                                    color = TaigaPalette.GoldBright,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(TaigaPalette.BgSecondary)
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text("📏 Габариты: длина ${c.lengthMm} • диаметр ${c.diameterMm}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                    Text("⚖️ Вес пули и заряд: ${c.bulletWeightAndPowder}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                    Text("🚀 Баллистика: V₀ = ${c.velocityV0} • E₀ = ${c.energyE0}", color = TaigaPalette.EmeraldAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("🏪 Магазин: ${c.storePrice} | 🔧 Самокрут: ${c.selfReloadPrice}", color = TaigaPalette.GoldAccent, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "🎯 Применение: ${c.descriptionAndGame}",
                                    color = TaigaPalette.TextPrimary,
                                    fontSize = 13.sp
                                )
                                if (c.reloadPowderName.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = {
                                            selectedCartridgeId = c.id
                                            subTab = 1
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("⚖️ Открыть рецепт самокрута и расчёт партии", color = TaigaPalette.GoldBright)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                val selected = cartridges.find { it.id == selectedCartridgeId } ?: cartridges.firstOrNull()
                val count = (batchCountText.toIntOrNull() ?: 25).coerceIn(1, 1000)

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().border(1.dp, TaigaPalette.BorderGold, RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    "⚖️ Калькулятор снаряжения патронов (19 калибров)",
                                    color = TaigaPalette.GoldBright,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    cartridges.forEach { c ->
                                        FilterChip(
                                            selected = c.id == selected?.id,
                                            onClick = { selectedCartridgeId = c.id },
                                            label = { Text(c.title.substringBefore(" ("), fontSize = 12.sp) }
                                        )
                                    }
                                }

                                OutlinedTextField(
                                    value = batchCountText,
                                    onValueChange = { batchCountText = it.filter { ch -> ch.isDigit() } },
                                    label = { Text("Количество патронов в партии (шт.)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                if (selected != null) {
                                    val totalStore = selected.storeCostRub * count
                                    val totalSelfReused = selected.selfReusedHullCostRub * count
                                    val savedRub = (totalStore - totalSelfReused).coerceAtLeast(0)
                                    val totalPowderG = ((selected.powderGramsPerRound * count) * 10.0).roundToInt() / 10.0
                                    val totalProjG = (selected.projectileGramsPerRound * count).roundToInt()

                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(TaigaPalette.BgSecondary)
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("📋 Калибр: ${selected.title}", color = TaigaPalette.GoldBright, fontWeight = FontWeight.Bold)
                                        Text("🧪 Порох: ${selected.reloadPowderName}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                        Text("☀️ Лето (+15 °C): ${selected.reloadSummerLoad}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                        Text("❄️ Зима (−20 °C): ${selected.reloadWinterLoad}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                        Text("🎯 Пуля: ${selected.reloadSlugLoad}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                        Text("🧱 Пыж и завальцовка: ${selected.reloadWadNote}", color = TaigaPalette.TextMuted, fontSize = 12.sp)
                                        Text("🔥 Капсюль: ${selected.reloadPrimer}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                        HorizontalDivider(color = TaigaPalette.BorderGold, modifier = Modifier.padding(vertical = 4.dp))
                                        Text(
                                            "📦 Расход на $count шт.: порох $totalPowderG г • дробь/пули $totalProjG г",
                                            color = TaigaPalette.GoldBright,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            "💰 В магазине: $totalStore ₽ | Своя гильза: $totalSelfReused ₽ (экономия $savedRub ₽)",
                                            color = TaigaPalette.EmeraldAccent,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                val filteredGuns = guns.filter {
                    q.isEmpty() || (it.name + " " + it.caliber + " " + it.type + " " + it.overview)
                        .lowercase().contains(q)
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredGuns, key = { it.id }) { g ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().border(1.dp, TaigaPalette.BorderGold, RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("🔫 ${g.name}", color = TaigaPalette.GoldBright, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text("${g.type} • Калибр: ${g.caliber} • Цена: ${g.priceRange}", color = TaigaPalette.EmeraldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("📏 Длина: ${g.overallLength} (ствол ${g.barrelLength}) • Магазин: ${g.magazineCapacity}", color = TaigaPalette.TextMuted, fontSize = 12.sp)
                                Text(g.overview, color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                                if (g.pros.isNotBlank()) {
                                    Text("✅ Плюсы: ${g.pros}", color = TaigaPalette.EmeraldAccent, fontSize = 12.sp)
                                }
                                if (g.cons.isNotBlank()) {
                                    Text("⚠️ Особенности: ${g.cons}", color = TaigaPalette.GoldAccent, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// 8.2 ЭКРАН «ПОЛЕВАЯ МЕДИЦИНА И ПЕРВАЯ ПОМОЩЬ» (С ДВОЙНЫМИ СХЕМАМИ v308 И ТАЙМЕРОМ ЖГУТА)
// ============================================================================

@Composable
fun FieldMedicineScreen(
    vm: OhotnikViewModel,
    searchQuery: String,
    onOpenZoom: (String, String) -> Unit
) {
    val allItems by vm.allMedItems.collectAsState()
    var activeSection by remember { mutableStateOf("body_zones") }

    val sections = listOf(
        "body_zones" to "🧍 Зоны ранений (9)",
        "trauma_atlas" to "🩸 Атлас травм (10)",
        "knife_only" to "🔪 Только нож (7)",
        "taiga_hacks" to "🌲 Таёжная мед. (7)",
        "plants" to "🌿 Травы и яды (13)",
        "tamponade" to "🩹 Тампонада (5)",
        "kit" to "🧰 Аптечка (18)",
        "dosages" to "💊 Дозировки (Транексам/Кеторолак)"
    )

    val q = searchQuery.trim().lowercase()
    val filtered = allItems.filter { item ->
        val matchSec = if (q.isNotEmpty()) true else item.section == activeSection
        val matchQuery = q.isEmpty() || (
            item.title + " " + item.symptomsOrSummary + " " +
                item.stepsWithKitJson + " " + item.stepsKnifeOnlyJson + " " + item.taigaSecret
            ).lowercase().contains(q)
        matchSec && matchQuery
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Панель экстренного запуска таймера жгута
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { vm.startTourniquetTimer(isWinterMode = false, zoneLabel = "Лето 60 мин") },
                colors = ButtonDefaults.buttonColors(containerColor = TaigaPalette.DangerRed),
                modifier = Modifier.weight(1f)
            ) {
                Text("⏱ Жгут: ЛЕТО (60м)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Button(
                onClick = { vm.startTourniquetTimer(isWinterMode = true, zoneLabel = "Зима 30 мин") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                modifier = Modifier.weight(1f)
            ) {
                Text("❄️ Жгут: ЗИМА (30м)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        // Подвкладки разделов полевой медицины
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            sections.forEach { (secKey, secTitle) ->
                FilterChip(
                    selected = activeSection == secKey && q.isEmpty(),
                    onClick = { activeSection = secKey },
                    label = { Text(secTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        if (activeSection == "dosages" && q.isEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.clinicalDosages, key = { it.name }) { drug ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().border(1.5.dp, TaigaPalette.GoldAccent, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("💊 ${drug.name}", color = TaigaPalette.GoldBright, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text(drug.group, color = TaigaPalette.EmeraldAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("💉 Полевая дозировка: ${drug.fieldDose}", color = TaigaPalette.TextPrimary, fontSize = 13.5.sp)
                            Text("📊 Суточный максимум: ${drug.maxDailyDose}", color = TaigaPalette.GoldAccent, fontSize = 12.5.sp)
                            Box(
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(TaigaPalette.DangerBg).padding(10.dp)
                            ) {
                                Text("⚠️ ${drug.warning}", color = Color(0xFFFECACA), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.id }) { item ->
                    MedCardItem(item = item, vm = vm, onOpenZoom = onOpenZoom)
                }
            }
        }
    }
}

@Composable
fun MedCardItem(
    item: MedItemEntity,
    vm: OhotnikViewModel,
    onOpenZoom: (String, String) -> Unit
) {
    val stepsKit = remember(item.stepsWithKitJson) { parseJsonStringList(item.stepsWithKitJson) }
    val stepsKnife = remember(item.stepsKnifeOnlyJson) { parseJsonStringList(item.stepsKnifeOnlyJson) }

    Card(
        colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.5.dp,
                color = if (item.isPoisonous) TaigaPalette.DangerRed else TaigaPalette.BorderGold,
                shape = RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.title,
                    color = TaigaPalette.GoldBright,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                if (item.section == "kit") {
                    Checkbox(
                        checked = item.isCheckedInKit,
                        onCheckedChange = { vm.toggleMedKitItem(item) }
                    )
                }
            }

            if (item.subtitleOrDanger.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (item.isPoisonous || item.section == "body_zones") TaigaPalette.DangerBg else TaigaPalette.BgElevated)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = item.subtitleOrDanger,
                        color = if (item.isPoisonous || item.section == "body_zones") Color(0xFFFECACA) else TaigaPalette.GoldAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            if (item.photoAsset.isNotBlank()) {
                Text("📸 1. Полевая фотография (нажмите для увеличения):", color = TaigaPalette.EmeraldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                AssetPhotoImage(
                    assetPath = item.photoAsset,
                    contentDescription = item.title,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(TaigaPalette.BgMain),
                    onClickZoom = { onOpenZoom(item.photoAsset, item.title) }
                )
            }

            if (item.schemeIllustrationAsset.isNotBlank()) {
                Text("🎨 2. Наглядная схема со стрелками v302 (нажмите для увеличения):", color = TaigaPalette.GoldBright, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                AssetPhotoImage(
                    assetPath = item.schemeIllustrationAsset,
                    contentDescription = "${item.title} — схема",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(TaigaPalette.BgMain),
                    onClickZoom = { onOpenZoom(item.schemeIllustrationAsset, "${item.title} (Схема)") }
                )
            }

            if (item.symptomsOrSummary.isNotBlank()) {
                Text(
                    text = "🔍 ${item.symptomsOrSummary}",
                    color = TaigaPalette.TextPrimary,
                    fontSize = 13.5.sp
                )
            }

            if (stepsKit.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(TaigaPalette.BgSecondary)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = if (item.section == "body_zones") "🧰 Пошаговая помощь С АПТЕЧКОЙ:" else "📋 Пошаговая инструкция действий:",
                        color = TaigaPalette.GoldBright,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.5.sp
                    )
                    stepsKit.forEachIndexed { idx, step ->
                        Text(
                            text = "${idx + 1}. $step",
                            color = TaigaPalette.TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            if (stepsKnife.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(TaigaPalette.BgElevated)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "🔪 Если с собой ТОЛЬКО НОЖ И ОДЕЖДА:",
                        color = TaigaPalette.EmeraldAccent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.5.sp
                    )
                    stepsKnife.forEachIndexed { idx, step ->
                        Text(
                            text = "${idx + 1}. $step",
                            color = TaigaPalette.TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            if (item.taigaSecret.isNotBlank()) {
                Text(
                    text = "🌲 ${item.taigaSecret}",
                    color = TaigaPalette.EmeraldAccent,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (item.forbiddenOrWarning.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TaigaPalette.DangerBg)
                        .border(1.dp, TaigaPalette.DangerRed, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "⛔ ${item.forbiddenOrWarning}",
                        color = Color(0xFFFECACA),
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ============================================================================
// 8.3 ЭКРАН «ПАМЯТКИ ОХОТНИКА, ВЫЖИВАНИЕ И МАРШРУТ ПОЛУЧЕНИЯ ЛИЦЕНЗИИ»
// ============================================================================

@Composable
fun SurvivalAndMemosScreen(
    vm: OhotnikViewModel,
    searchQuery: String
) {
    val survivalMemos by vm.survivalMemos.collectAsState()
    val licensingSteps by vm.licensingSteps.collectAsState()
    var mode by remember { mutableIntStateOf(0) } // 0 = Выживание в тайге, 1 = 10 шагов к лицензии

    val q = searchQuery.trim().lowercase()
    val list = if (mode == 0) survivalMemos else licensingSteps
    val filtered = list.filter {
        q.isEmpty() || (it.title + " " + it.subtitle + " " + it.instructions).lowercase().contains(q)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = mode == 0,
                onClick = { mode = 0 },
                label = { Text("🌲 Выживание в тайге (${survivalMemos.size})", fontWeight = FontWeight.Bold) }
            )
            FilterChip(
                selected = mode == 1,
                onClick = { mode = 1 },
                label = { Text("📋 Лицензия и справки (${licensingSteps.size})", fontWeight = FontWeight.Bold) }
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filtered, key = { it.id }) { memo ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, TaigaPalette.BorderGold, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(memo.title, color = TaigaPalette.GoldBright, fontWeight = FontWeight.ExtraBold, fontSize = 15.5.sp)
                        if (memo.subtitle.isNotBlank()) {
                            Text(memo.subtitle, color = TaigaPalette.EmeraldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        if (memo.badgeOrCost.isNotBlank()) {
                            Text("💰 ${memo.badgeOrCost}", color = TaigaPalette.GoldAccent, fontSize = 12.sp)
                        }
                        Text(memo.instructions, color = TaigaPalette.TextPrimary, fontSize = 13.5.sp)
                    }
                }
            }
        }
    }
}

// ============================================================================
// 8.4 ЭКРАН «ЭНЦИКЛОПЕДИЯ ЗВЕРЕЙ И ПТИЦ РОССИИ (38 ВИДОВ + ВЕТКОНТРОЛЬ)»
// ============================================================================

@Composable
fun FaunaCatalogScreen(
    vm: OhotnikViewModel,
    searchQuery: String,
    onOpenZoom: (String, String) -> Unit
) {
    val faunaList by vm.faunaList.collectAsState()
    val q = searchQuery.trim().lowercase()
    val filtered = faunaList.filter {
        q.isEmpty() || (it.name + " " + it.category + " " + it.habitat + " " + it.tacticsAndWeapons + " " + it.vetDiseases)
            .lowercase().contains(q)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(filtered, key = { it.id }) { f ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TaigaPalette.BgCard),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, TaigaPalette.BorderGold, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssetPhotoImage(
                        assetPath = f.imageAsset,
                        contentDescription = f.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(175.dp)
                            .clip(RoundedCornerShape(10.dp)),
                        onClickZoom = { onOpenZoom(f.imageAsset, f.name) }
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🦌 ${f.name}", color = TaigaPalette.GoldBright, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        IconButton(onClick = { vm.toggleFaunaFavorite(f) }) {
                            Text(if (f.isFavorite) "★" else "☆", color = TaigaPalette.GoldBright, fontSize = 20.sp)
                        }
                    }
                    Text("📍 Ареал: ${f.regionsText} • Категория: ${f.category}", color = TaigaPalette.EmeraldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("📅 Сезон: ${f.season} • Норма: ${f.limitsAndNorms}", color = TaigaPalette.TextMuted, fontSize = 12.sp)
                    Text("🎯 Оружие и тактика: ${f.tacticsAndWeapons}", color = TaigaPalette.TextPrimary, fontSize = 13.sp)
                    if (f.vetStatus.isNotBlank()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(TaigaPalette.BgSecondary)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("🔬 Ветконтроль: ${f.vetStatus}", color = TaigaPalette.GoldBright, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text("Что проверять: ${f.vetInspect}", color = TaigaPalette.TextPrimary, fontSize = 12.sp)
                            Text("Опасные болезни: ${f.vetDiseases}", color = Color(0xFFFCA5A5), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun parseJsonStringList(raw: String): List<String> {
    if (raw.isBlank()) return emptyList()
    return try {
        val arr = JSONArray(raw)
        List(arr.length()) { i -> arr.optString(i) }.filter { it.isNotBlank() }
    } catch (_: Exception) {
        emptyList()
    }
}

// ============================================================================
// 9. ТОЧКА ВХОДА НАТИВНОГО ANDROID-ПРИЛОЖЕНИЯ (MainActivity)
// ============================================================================

class MainActivity : ComponentActivity() {
    private val viewModel: OhotnikViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OhotnikTaigaTheme {
                OhotnikMainScreen(vm = viewModel)
            }
        }
    }
}
