package ru.rusia.ohot293

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cartridges")
data class CartridgeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val lengthMm: String,
    val diameterMm: String,
    val bulletWeightAndPowder: String,
    val velocityV0: String,
    val energyE0: String,
    val storePrice: String,
    val selfReloadPrice: String,
    val descriptionAndGame: String,
    val imageAsset: String,
    val reloadPowderName: String,
    val reloadSummerLoad: String,
    val reloadWinterLoad: String,
    val reloadSlugLoad: String,
    val reloadWadNote: String,
    val reloadPrimer: String,
    val storeCostRub: Int,
    val selfNewHullCostRub: Int,
    val selfReusedHullCostRub: Int,
    val powderGramsPerRound: Double,
    val projectileGramsPerRound: Double,
    val costBreakdown: String
)

@Entity(tableName = "guns")
data class GunEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val type: String,
    val caliber: String,
    val priceRange: String,
    val imageAsset: String,
    val ammoId: String,
    val overallLength: String,
    val barrelLength: String,
    val magazineCapacity: String,
    val shortDescription: String,
    val overview: String,
    val pros: String,
    val cons: String,
    val inspectionTips: String,
    val recommendedAmmo: String,
    val maintenance: String
)

@Entity(tableName = "med_items")
data class MedItemEntity(
    @PrimaryKey val id: String,
    val section: String, // "body_zones" | "trauma_atlas" | "knife_only" | "taiga_hacks" | "plants" | "kit" | "tamponade"
    val category: String,
    val title: String,
    val subtitleOrDanger: String,
    val badge: String,
    val symptomsOrSummary: String,
    val stepsWithKitJson: String,
    val stepsKnifeOnlyJson: String,
    val forbiddenOrWarning: String,
    val taigaSecret: String,
    val photoAsset: String,
    val schemeIllustrationAsset: String,
    val isPoisonous: Boolean = false,
    val isCheckedInKit: Boolean = false
)

@Entity(tableName = "survival_memos")
data class SurvivalMemoEntity(
    @PrimaryKey val id: String,
    val section: String, // "survival" | "licensing_steps" | "safe_checks"
    val title: String,
    val subtitle: String,
    val instructions: String,
    val badgeOrCost: String
)

@Entity(tableName = "fauna")
data class FaunaEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val season: String,
    val limitsAndNorms: String,
    val tacticsAndWeapons: String,
    val imageAsset: String,
    val regionsText: String,
    val habitat: String,
    val tracesAndSigns: String,
    val recommendedAmmo: String,
    val huntingMethods: String,
    val fieldDressingAndCooking: String,
    val vetStatus: String,
    val vetInspect: String,
    val vetDiseases: String,
    val vetConsequences: String,
    val isFavorite: Boolean = false
)
