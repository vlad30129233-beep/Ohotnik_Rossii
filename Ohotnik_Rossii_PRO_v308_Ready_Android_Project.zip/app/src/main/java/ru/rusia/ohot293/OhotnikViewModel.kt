package ru.rusia.ohot293

import android.app.Application
import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

class NativeHardwareController(private val context: Context) {
    private var isTorchOn = false

    fun toggleTorch(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return false
            isTorchOn = !isTorchOn
            cm.setTorchMode(cameraId, isTorchOn)
            vibrate(80)
            isTorchOn
        } catch (e: Exception) {
            false
        }
    }

    fun vibrate(durationMs: Long = 250L) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    suspend fun playEmergencyWhistle3000Hz(durationMs: Int = 2500) = withContext(Dispatchers.Default) {
        val sampleRate = 44100
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val samples = ShortArray(numSamples)
        val freqHz = 3000.0
        for (i in 0 until numSamples) {
            val angle = 2.0 * PI * i * freqHz / sampleRate
            samples[i] = (sin(angle) * Short.MAX_VALUE).toInt().toShort()
        }
        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(samples.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        audioTrack.write(samples, 0, samples.size)
        audioTrack.play()
        delay(durationMs.toLong())
        audioTrack.stop()
        audioTrack.release()
    }
}

data class ClinicalDrugDosage(
    val name: String,
    val group: String,
    val fieldDose: String,
    val maxDailyDose: String,
    val warning: String
)

class OhotnikViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val dao = db.dao()
    val hardware = NativeHardwareController(application)

    val isSeeding = MutableStateFlow(true)
    val searchQuery = MutableStateFlow("")

    val cartridges: StateFlow<List<CartridgeEntity>> = dao.observeCartridges()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val guns: StateFlow<List<GunEntity>> = dao.observeGuns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMedItems: StateFlow<List<MedItemEntity>> = dao.observeAllMedItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val survivalMemos: StateFlow<List<SurvivalMemoEntity>> = dao.observeMemosBySection("survival")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val licensingSteps: StateFlow<List<SurvivalMemoEntity>> = dao.observeMemosBySection("licensing_steps")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val faunaList: StateFlow<List<FaunaEntity>> = dao.observeFauna()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val clinicalDosages = listOf(
        ClinicalDrugDosage(
            name = "Транексамовая кислота (Транексам)",
            group = "Гемостатик (антифибринолитик)",
            fieldDose = "1000 мг (2 ампулы по 5 мл / 500 мг или 4 таб. по 250 мг) в первые 3 часа после ранения",
            maxDailyDose = "До 2000 мг в сутки",
            warning = "Критически важно ввести в первые 3 часа при массивной кровопотере. Не смешивать в одном шприце с другими препаратами."
        ),
        ClinicalDrugDosage(
            name = "Кеторолак (Кетанов / Кеторол)",
            group = "Ненаркотический анальгетик (НПВС)",
            fieldDose = "30 мг (1 мл в/м глубоко в мышцу бедра или плеча) либо 10–20 мг внутрь",
            maxDailyDose = "До 90 мг в сутки (не более 2 дней подряд)",
            warning = "Обезболивает через 15–20 мин. Противопоказан при подозрении на продолжающееся внутреннее кровотечение в ЖКТ."
        ),
        ClinicalDrugDosage(
            name = "Цефтриаксон",
            group = "Антибиотик широкого спектра (цефалоспорин III поколения)",
            fieldDose = "1000–2000 мг (1–2 флакона), развести в 3,5 мл воды для инъекций или 1% лидокаина (при отсутствии аллергии!), вводить в/м",
            maxDailyDose = "2000 мг (1 раз в сутки) при огнестрельных ранениях и укусах зверя",
            warning = "Обязательна проба на переносимость лидокаина! При сомнениях разводить только стерильной водой для инъекций или физраствором 0,9%."
        )
    )

    // Таймер наложенного кровоостанавливающего жгута (зима 30 мин / лето 60 мин)
    val tourniquetRemainingSec = MutableStateFlow(0)
    val tourniquetZoneLabel = MutableStateFlow("")
    private var tqTimerJob: Job? = null

    init {
        viewModelScope.launch {
            JsonAssetSeeder.ensureSeeded(getApplication(), db)
            isSeeding.value = false
        }
    }

    fun startTourniquetTimer(isWinterMode: Boolean, zoneLabel: String) {
        tqTimerJob?.cancel()
        val totalSeconds = if (isWinterMode) 30 * 60 else 60 * 60
        tourniquetZoneLabel.value = zoneLabel
        tourniquetRemainingSec.value = totalSeconds
        hardware.vibrate(400)
        tqTimerJob = viewModelScope.launch {
            while (isActive && tourniquetRemainingSec.value > 0) {
                delay(1000L)
                tourniquetRemainingSec.value -= 1
                if (tourniquetRemainingSec.value == 300 || tourniquetRemainingSec.value == 60 || tourniquetRemainingSec.value == 0) {
                    hardware.vibrate(1000)
                }
            }
        }
    }

    fun stopTourniquetTimer() {
        tqTimerJob?.cancel()
        tourniquetRemainingSec.value = 0
        tourniquetZoneLabel.value = ""
    }

    fun toggleMedKitItem(item: MedItemEntity) {
        viewModelScope.launch {
            dao.updateMedKitChecked(item.id, !item.isCheckedInKit)
        }
    }

    fun toggleFaunaFavorite(item: FaunaEntity) {
        viewModelScope.launch {
            dao.updateFaunaFavorite(item.id, !item.isFavorite)
        }
    }

    fun triggerWhistle() {
        viewModelScope.launch {
            hardware.playEmergencyWhistle3000Hz(2500)
        }
    }
}
