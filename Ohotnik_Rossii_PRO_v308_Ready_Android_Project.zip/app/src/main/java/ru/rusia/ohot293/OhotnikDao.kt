package ru.rusia.ohot293

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface OhotnikDao {
    @Query("SELECT * FROM cartridges ORDER BY id ASC")
    fun observeCartridges(): Flow<List<CartridgeEntity>>

    @Query("SELECT * FROM guns ORDER BY id ASC")
    fun observeGuns(): Flow<List<GunEntity>>

    @Query("SELECT * FROM med_items WHERE section = :section ORDER BY id ASC")
    fun observeMedBySection(section: String): Flow<List<MedItemEntity>>

    @Query("SELECT * FROM med_items ORDER BY id ASC")
    fun observeAllMedItems(): Flow<List<MedItemEntity>>

    @Query("UPDATE med_items SET isCheckedInKit = :checked WHERE id = :id")
    suspend fun updateMedKitChecked(id: String, checked: Boolean)

    @Query("SELECT * FROM survival_memos WHERE section = :section ORDER BY id ASC")
    fun observeMemosBySection(section: String): Flow<List<SurvivalMemoEntity>>

    @Query("SELECT * FROM fauna ORDER BY id ASC")
    fun observeFauna(): Flow<List<FaunaEntity>>

    @Query("UPDATE fauna SET isFavorite = :fav WHERE id = :id")
    suspend fun updateFaunaFavorite(id: String, fav: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartridges(items: List<CartridgeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGuns(items: List<GunEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedItems(items: List<MedItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSurvivalMemos(items: List<SurvivalMemoEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFauna(items: List<FaunaEntity>)

    @Query("SELECT COUNT(*) FROM cartridges")
    suspend fun getCartridgeCount(): Int
}
